package zah.mobile.appcuaca;

public class Cuaca {
    public String tanggal;
    public String kondisi;
    public int gambar;
    public int kodeCuaca;

    public Cuaca(String t,  int k){
        this.tanggal = t;
        this.kondisi = getKondisi(k);
        this.gambar = getGambar(k);
        this.kodeCuaca = k;
    }

    private int getGambar(int kode) {
        if (kode >= 95) {
            return R.drawable.rain_storm;
        } else if (kode >= 45) {
            return R.drawable.fog;
        } else if (kode >= 80) {
            return R.drawable.rainy;
        } else {
            return R.drawable.sunny;
        }
    }

    private String getKondisi(int kode) {
        if (kode >= 95) {
            return "Thunderstorm";
        } else if (kode >= 45) {
            return "Fog";
        } else if (kode >= 80) {
            return "Rain showers";
        } else {
            return "Clear Sky";
        }
    }
}
